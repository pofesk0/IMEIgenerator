package imei.generator;

import android.app.*;
import android.app.admin.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    private TextView input;

	
	@Override
    protected void onResume() {
        super.onResume();
		getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        ComponentName adminComponent = new ComponentName(this, MyDeviceAdminReceiver.class);
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

        if (!dpm.isAdminActive(adminComponent)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
			String explanation;
			if ("ru".equalsIgnoreCase(Locale.getDefault().getLanguage())) {
				explanation = "Предположим, что вас остановили на улице и просят показать IMEI вашего телефона. Вы вероятно не хотите это делать. Также чтобы набрать *#06# обычно нужно разблокировать телефон. Вы вероятно тоже не хотите это делать. Данное приложение решает эту проблему. Вы можете неверно ввести пароль и тогда оно запустится на заблокированном экране имитируя фейковый телефон. Там вы наберёте *#06# и оно покажет фейковый IMEI. Требует DEVICE_ADMIN для отслеживания неверных попыток ввода пароля. Поэтому мы сейчас его запрашиваем. Данные не передаются. Приложение не имеет доступа в интернет.";
				} else {
					explanation = "Let's say you're stopped on the street and asked to show your phone's IMEI. You probably don't want to do that. Also, to dial *#06#, you usually need to unlock your phone. You probably don't want to do that either. This app solves that problem. You can enter the password incorrectly, and then it will launch on the lock screen, simulating a fake phone. There, you can dial *#06#, and it will show the fake IMEI. Requires DEVICE_ADMIN to track incorrect password attempts, so we're asking for it now. No data is transferred. The app does not have internet access.";
				}
			intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, explanation);
			startActivity(intent);
		}}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Корневой контейнер
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(20,20,20,20);
        root.setGravity(Gravity.BOTTOM);

        // Верхняя панель: поле ввода и кнопка удаления
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        input = new TextView(this);
        input.setTextSize(36);
        input.setTextColor(Color.WHITE);
        input.setGravity(Gravity.START);
        input.setPadding(10,10,10,10);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1f);
        top.addView(input,inputParams);

        Button del = createRoundedButton("⌫", Color.DKGRAY, Color.WHITE);
        del.setTextSize(28);
        del.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String t = input.getText().toString();
					if(t.length()>0) input.setText(t.substring(0,t.length()-1));
				}
			});
        top.addView(del, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Клавиатура 3x4
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_MARGINS);
        grid.setUseDefaultMargins(true);

        String[] keys = {"1","2","3","4","5","6","7","8","9","*","0","#"};
        for(final String key: keys){
            Button btn = createRoundedButton(key, Color.DKGRAY, Color.WHITE);
            btn.setTextSize(26);
            btn.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						input.append(key);
						checkIMEI();
					}
				});
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0;
            p.height = GridLayout.LayoutParams.WRAP_CONTENT;
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED,1f);
            grid.addView(btn,p);
        }

        root.addView(grid, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Кнопка CALL под клавиатурой
        Button call = createRoundedButton("📞", Color.GREEN, Color.WHITE);
        call.setTextSize(32);
        call.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					checkIMEI();
				}
			});
        LinearLayout.LayoutParams callParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        callParams.topMargin = 20;
        root.addView(call,callParams);

        setContentView(root);
    }

    // Создание кнопки со скруглёнными углами
    private Button createRoundedButton(String text, int bgColor, int textColor){
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(22);

        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(25);
        gd.setColor(bgColor);
        btn.setBackground(gd);

        return btn;
    }

    private void checkIMEI() {
		String t = input.getText().toString();
		if (t.contains("*#06#")) {
			String imei = generateIMEI();

			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("IMEI:");
			builder.setMessage(imei);
			builder.setPositiveButton("OK", null);

			AlertDialog dialog = builder.create();

			// Скругляем углы окна
			if (dialog.getWindow() != null) {
				GradientDrawable bg = new GradientDrawable();
				bg.setColor(Color.WHITE);
				bg.setCornerRadius(40); // радиус скругления
				dialog.getWindow().setBackgroundDrawable(bg);
			}

			dialog.show();

			// Сдвигаем текст немного вниз после показа диалога
			TextView messageView = dialog.findViewById(android.R.id.message);
			if (messageView != null) {
				messageView.setPadding(
					messageView.getPaddingLeft(),
					messageView.getPaddingTop() + 30, // немного ниже
					messageView.getPaddingRight(),
					messageView.getPaddingBottom()
				);
			}

			input.setText("");
		}
	}
    

    // Генерация IMEI с алгоритмом Луна
    private String generateIMEI(){
        int[] digits = new int[14];
        Random r = new Random();
        for(int i=0;i<14;i++) digits[i] = r.nextInt(10);

        int sum=0;
        for(int i=0;i<14;i++){
            int d = digits[i];
            if(i%2==1){
                d*=2;
                if(d>9) d-=9;
            }
            sum+=d;
        }

        int check = (10 - sum%10)%10;

        StringBuilder sb = new StringBuilder();
        for(int d: digits) sb.append(d);
        sb.append(check);
        return sb.toString();
    }
}
